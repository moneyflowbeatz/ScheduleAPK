package com.example.schedule.models

data class ScheduleItem(
    val time: String,
    val subject: String
)
