package com.example.schedule

data class CreateUserRequest(
    val login: String,
    val password: String
)