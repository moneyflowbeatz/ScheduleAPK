package com.example.schedule

data class Student(
    val fio: String,
    val userId: Int,
    val groupId: Int
)