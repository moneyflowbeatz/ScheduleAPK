package com.example.schedule.models

data class LoginResponse(
    val token: String
)
