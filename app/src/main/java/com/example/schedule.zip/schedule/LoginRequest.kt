package com.example.schedule

data class LoginRequest(
    val login: String,
    val password: String
)
