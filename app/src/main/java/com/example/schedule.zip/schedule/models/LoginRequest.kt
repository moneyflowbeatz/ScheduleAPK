package com.example.schedule.models

data class LoginRequest(
    val username: String,
    val password: String
)
