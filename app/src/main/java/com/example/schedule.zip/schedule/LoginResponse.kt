package com.example.schedule

data class LoginResponse(val token: String)